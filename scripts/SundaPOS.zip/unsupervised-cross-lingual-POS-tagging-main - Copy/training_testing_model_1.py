import sklearn_crfsuite
from sklearn_crfsuite import metrics

# Data latih: list of sentences where each sentence is a list of (word, tag) pairs
train_sents = [[("John", "NNP"), ("is", "VBZ"), ("running", "VBG"), ("fast", "RB")]]
test_sents = [[("She", "PRP"), ("walks", "VBZ"), ("slowly", "RB")]]

# Feature extraction function
def word2features(sent, i):
    word = sent[i][0]
    features = {
        'word': word,
        'is_first': i == 0,
        'is_last': i == len(sent) - 1,
        'is_capitalized': word[0].upper() == word[0],
        'is_digit': word.isdigit(),
    }
    return features

# Prepare dataset
X_train = [[word2features(s, i) for i in range(len(s))] for s in train_sents]
y_train = [[tag for word, tag in s] for s in train_sents]

# Train CRF model
crf = sklearn_crfsuite.CRF(algorithm='lbfgs')
crf.fit(X_train, y_train)

# Predict and evaluate
X_test = [[word2features(s, i) for i in range(len(s))] for s in test_sents]
y_test = [[tag for word, tag in s] for s in test_sents]
y_pred = crf.predict(X_test)
print(metrics.flat_classification_report(y_test, y_pred))
