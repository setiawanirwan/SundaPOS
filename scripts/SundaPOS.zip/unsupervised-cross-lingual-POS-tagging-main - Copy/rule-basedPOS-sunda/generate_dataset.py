
# print(hasil_tagging)
import sys
import os

source_file = sys.argv[1]
output_folder= sys.argv[2]

def loadPOSData(source_file):
    lexicon = {}
    lineCount = 0
    with open(source_file, 'r',  encoding='utf-8') as file:
        # Read each line in the file
        for line in file:
            lineCount = lineCount + 1
            # add all lexicon_dict
            if lineCount > 4:
                word = line.strip()
                dataWord = word.split()
                tempWord = dataWord[0]
                pos = ''
                count = 0
                for i in range(len(dataWord)-1):
                    dataPOS = dataWord[i+1].split("_")
                    if dataPOS[0] != '***':
                        tempCount = int(dataPOS[1])
                        if tempCount > count :
                            pos = dataPOS[0]
                            count = tempCount
                if pos != '':
                    lexicon[tempWord.lower()] = pos 
    return lexicon

def addUnknowPOSData(source_file, lexicon):
    lineCount = 0
    with open(source_file, 'r',  encoding='utf-8') as file:
        # Read each line in the file
        for line in file:
            lineCount = lineCount + 1
            # add all lexicon_dict
            if lineCount > 4:
                word = line.strip()
                dataWord = word.split()
                tempWord = dataWord[0]
                if len(dataWord) == 2:
                    dataPOS = dataWord[1].split("_")
                    if dataPOS[0] == '***':
                        if tempWord.lower() not in lexicon:
                            lexicon[tempWord.lower()] = '***' 
    return lexicon
dataPOS = loadPOSData(source_file)
dataPOS = addUnknowPOSData(source_file, dataPOS)
# Mengambil nilai unik
listPOS = set(dataPOS.values())
print(listPOS)


# Membuat folder jika belum ada
if not os.path.exists(output_folder):
    os.makedirs(output_folder)

for pos in listPOS:
    words_data = list(filter(lambda key: dataPOS[key] == pos, dataPOS))
    if pos == "***":
        pos = "unknown"
    with open(output_folder+"/"+pos+".txt", 'w', encoding='UTF-8') as words:
        for data in words_data:
            words.write( data + '\n')