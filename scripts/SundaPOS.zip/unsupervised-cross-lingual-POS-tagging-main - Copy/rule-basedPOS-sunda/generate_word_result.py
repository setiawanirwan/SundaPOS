#generate kata dan POS dengan algo yg berbeda
# print(hasil_tagging)
import sys
import os

source_file_1 = sys.argv[1]
source_file_2 = sys.argv[2]
output_file= sys.argv[3]

def loadPOSData(source_file):
    lexicon = {}
    lineCount = 0
    with open(source_file, 'r',  encoding='utf-8') as file:
        # Read each line in the file
        for line in file:
            lineCount = lineCount + 1
            # add all lexicon_dict
            if lineCount > 4:
                word = line.strip()
                dataWord = word.split()
                tempWord = dataWord[0]
                dataPOS = dataWord[1].split("_")
                lexicon[tempWord] = dataPOS[0] 
    return lexicon

dataPOS_1 = loadPOSData(source_file_1)

dataPOS_2 = loadPOSData(source_file_2)
# Mengambil nilai unik


# Membuat folder jika belum ada
with open(output_file, 'w', encoding='UTF-8') as words:
    words_data = list(dataPOS_1)
    for data in words_data:
        words.write(data +'\t'+dataPOS_1[data]+'\t'+dataPOS_2[data]+'\n')