import spacy
import sys
# HOW TO USE
# python .\tagging_with_spacy.py source_file_path output_file_path 
# python .\tagging_with_spacy.py .\giza_workspace\Inggris_kejadian_1.txt .\giza_workspace\Tagged_inggris_kejadian_1.txt

# Load English model
# if model not found execute command python -m spacy download en_core_web_sm 
nlp = spacy.load("en_core_web_sm")

# Example:
# Input text
# text = "In the beginning God created the heavens and the earth. "
# doc = nlp(text)

# # Print POS tags
# for token in doc:
#     print(token.text, token.pos_)

# Reading alignment keys
def read_file_into_list(file):
    list = []
    with open(file, 'r', encoding='UTF-8') as fin:
        for line in fin.readlines():
            list.append(line.strip())
    return list

# Input parameters
source_file = sys.argv[1]
output_file = sys.argv[2]
list_sentences = read_file_into_list(source_file)
tagged_sentences = []
for sentence in list_sentences:
    doc = nlp(sentence)
    tagged_sentence = ''
    for token in doc:
        tagged_sentence = tagged_sentence + token.text + '_' + token.pos_ + ' '
    tagged_sentences.append(tagged_sentence)
id = 1
with open(output_file, 'w', encoding='UTF-8') as tagged_file:
    for data in tagged_sentences:
        tagged_file.write(str(id) + '\t' + data + '\n')
        id = id + 1