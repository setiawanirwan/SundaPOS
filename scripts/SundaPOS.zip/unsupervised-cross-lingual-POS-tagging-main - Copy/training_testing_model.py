import sklearn_crfsuite
from sklearn_crfsuite import metrics
import sys

def read_file_into_list(file):
    list = []
    with open(file, 'r', encoding='UTF-8') as fin:
        for line in fin.readlines():
            list.append(line.strip())
    return list

def dataFileToTuples(trainFile):
    listSentences = read_file_into_list(trainFile)
    listTrainData = []
    for sentence in listSentences:
        words = sentence.split(" ")
        listTuples = []
        for word in words :
            elements = word.split("_")
            listTuples.append((elements[0], elements[1]))
        listTrainData.append(listTuples)
    return listTrainData

def dataFileToTuplesWithId(trainFile):
    listSentences = read_file_into_list(trainFile)
    listTrainData = []
    for sentence in listSentences:
        elements = sentence.split("\t")
        words = elements[1].split(" ")
        listTuples = []
        for word in words :
            elements = word.split("_")
            listTuples.append((elements[0], elements[1]))
        listTrainData.append(listTuples)
    return listTrainData

# Input parameters
train_file = sys.argv[1]
test_file = sys.argv[2]

# train_sents = dataFileToTuples(train_file)

train_sents = dataFileToTuplesWithId(train_file)
test_sents = dataFileToTuplesWithId(test_file)

# Data latih: list of sentences where each sentence is a list of (word, tag) pairs
# train_sents = [
#     [("Abdi", "PRP"), ("teu", "NEG"), ("ngartos", "VB"), ("bahasa", "NN"), ("Inggris", "NNP")],
#     [("Manuk", "NN"), ("hiber", "VB"), ("di", "IN"), ("langit", "NN")],
# ]

# test_sents = [
#     [("Kami", "PRP"), ("nyerat", "VB"), ("surat", "NN")],
#     [("Buku", "NN"), ("eta", "DT"), ("kagungan", "VB"), ("anjeun", "PRP")],
# ]


# Feature extraction function
def word2features(sent, i):
    word = sent[i][0]
    features = {
        'bias': 1.0,  # Bias term
        'word.lower()': word.lower(),
        'word[-3:]': word[-3:],  # Akhiran tiga huruf
        'word[-2:]': word[-2:],  # Akhiran dua huruf
        'word.isupper()': word.isupper(),  # Huruf besar semua
        'word.istitle()': word.istitle(),  # Huruf kapital pertama
        'word.isdigit()': word.isdigit(),  # Angka
        'is_first': i == 0,  # Posisi pertama dalam kalimat
        'is_last': i == len(sent) - 1,  # Posisi terakhir dalam kalimat
    }
    if i > 0:
        word1 = sent[i - 1][0]
        features.update({
            '-1:word.lower()': word1.lower(),
            '-1:word.istitle()': word1.istitle(),
            '-1:word.isupper()': word1.isupper(),
        })
    else:
        features['BOS'] = True  # Awal kalimat

    if i < len(sent) - 1:
        word1 = sent[i + 1][0]
        features.update({
            '+1:word.lower()': word1.lower(),
            '+1:word.istitle()': word1.istitle(),
            '+1:word.isupper()': word1.isupper(),
        })
    else:
        features['EOS'] = True  # Akhir kalimat

    return features

def sent2features(sent):
    return [word2features(sent, i) for i in range(len(sent))]

def sent2labels(sent):
    return [label for _, label in sent]

def sent2tokens(sent):
    return [token for token, _ in sent]


# Prepare dataset
X_train = [sent2features(s) for s in train_sents]
y_train = [sent2labels(s) for s in train_sents]

X_test = [sent2features(s) for s in test_sents]
y_test = [sent2labels(s) for s in test_sents]

# Train CRF model
# Inisialisasi model CRF
crf = sklearn_crfsuite.CRF(
    algorithm='lbfgs',
    c1=0.1,  # Koefisien regularisasi L1
    c2=0.1,  # Koefisien regularisasi L2
    max_iterations=100,  # Iterasi maksimum
    all_possible_transitions=True
)

# Latih model
crf.fit(X_train, y_train)

# Predict and evaluate
# Prediksi
y_pred = crf.predict(X_test)
print(y_pred)
# Laporan hasil evaluasi
print(metrics.flat_classification_report(y_test, y_pred, digits=3))

#menyimpan model
# import pickle

# # Simpan model ke file
# with open('sunda_pos_crf.pkl', 'wb') as f:
#     pickle.dump(crf, f)

# # Muat model dari file
# with open('sunda_pos_crf.pkl', 'rb') as f:
#     loaded_crf = pickle.load(f)
