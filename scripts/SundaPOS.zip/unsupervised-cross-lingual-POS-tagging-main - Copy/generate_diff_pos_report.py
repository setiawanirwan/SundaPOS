import sys
import os

def loadPOSData(source_file):
    lexicon = {}
    lineCount = 0
    with open(source_file, 'r',  encoding='utf-8') as file:
        # Read each line in the file
        for line in file:
            lineCount = lineCount + 1
            # add all lexicon_dict
            if lineCount > 4:
                word = line.strip()
                dataWord = word.split()
                tempWord = dataWord[0]
                pos = ''
                count = 0
                for i in range(len(dataWord)-1):
                    dataPOS = dataWord[i+1].split("_")
                    if dataPOS[0] != '***':
                        tempCount = int(dataPOS[1])
                        if tempCount > count :
                            pos = dataPOS[0]
                            count = tempCount
                    else:
                        if (i + 2) == len(dataWord):
                            pos = dataPOS[0]

                if pos != '':
                    lexicon[tempWord.lower()] = pos 
    return lexicon


source_file_1 = sys.argv[1]
source_file_2 = sys.argv[2]
output_folder= sys.argv[3]

if not os.path.exists(output_folder):
    os.makedirs(output_folder)

dict_1 = loadPOSData(source_file_1)
dict_2 = loadPOSData(source_file_2)
listKey = set(dict_1.keys())
listKey2 = set(dict_2.keys())

listSame = []
listDiff = []
for word in listKey:
    pos1 = dict_1[word]
    pos2 = dict_2[word]
    if pos1 == pos2:
        listSame.append(word)
    else :
        listDiff.append(word)

with open(output_folder+"/samePOS.txt", 'w', encoding='UTF-8') as words:
        for data in listSame:
            words.write( data+"_"+dict_1[data]+ '\n')

with open(output_folder+"/differentPOS.txt", 'w', encoding='UTF-8') as words:
        for data in listDiff:
            words.write( data+"_"+dict_1[data]+"_"+dict_2[data]+ '\n')