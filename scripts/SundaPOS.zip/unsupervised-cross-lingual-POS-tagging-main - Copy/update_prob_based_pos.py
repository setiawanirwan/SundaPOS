
# print(hasil_tagging)
import sys
import os

source_file_1 = sys.argv[1] # file pos
source_file_2 = sys.argv[2] # file prob
output_file= sys.argv[3] #output file new prob

# Reading alignment keys
def read_file_into_list(file):
    list = []
    with open(file, 'r', encoding='UTF-8') as fin:
        for line in fin.readlines():
            list.append(line.strip())
    return list

dataPos = read_file_into_list(source_file_1)
dataProb = read_file_into_list(source_file_2)

# Mengambil update data prob
i = 0
updatedDataProbs = []
for data in dataProb:
    poss = dataPos[i].split()
    probs = data.split()
    #update probs
    for j in range(1, len(probs)):
        pos_element = poss[j].split('_')
        # if pos_element[1] != "***" and probs[j] == '0':
        if pos_element[1] != "***": #ubah semua prob jadi 1
            probs[j] = '1'
    i = i + 1
    #rebuild probs
    new_prob = ''
    for j in range(len(probs)):
        if j == 0:
            new_prob = new_prob + probs[j] + "\t"
        else: 
            new_prob = new_prob + probs[j] + " "
    updatedDataProbs.append(new_prob)

# Menulis data ke file
with open(output_file, 'w', encoding='UTF-8') as words:
    for data in updatedDataProbs:
        words.write(data+'\n')