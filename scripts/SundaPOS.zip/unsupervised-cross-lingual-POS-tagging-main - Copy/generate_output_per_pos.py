import os
import sys

def read_file_into_list(file):
    list = []
    with open(file, 'r', encoding='UTF-8') as fin:
        for line in fin.readlines():
            list.append(line.strip())
    return list

# Input parameters
source_file = sys.argv[1]
output_folder = sys.argv[2]
list_sentences = read_file_into_list(source_file)
dataPOS = {}
for sentences in list_sentences:   
    elements = sentences.split("\t")
    words = elements[1].split(" ")
    for word in words :
       elements = word.split("_")
       if elements[1] not in dataPOS:
           dataPOS[elements[1]] = []
       dataPOS[elements[1]].append(elements[0])
# Membuat folder jika belum ada
if not os.path.exists(output_folder):
    os.makedirs(output_folder)

keyPOS = set(dataPOS.keys()) 
for pos in keyPOS:
    words_data = dataPOS[pos]
    if pos == "***":
        pos = "unknown"
    with open(output_folder+"/"+pos+".txt", 'w', encoding='UTF-8') as words:
        for data in words_data:
            words.write( data + '\n')