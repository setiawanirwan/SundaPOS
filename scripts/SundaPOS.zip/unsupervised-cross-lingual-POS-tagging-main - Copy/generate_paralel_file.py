import sys
# HOW TO USE
# python .\generate_paralel_file.py source_file_path target_file_path output_file_path 
# python .\addingId.py .\giza_workspace\Inggris_kejadian_1.txt .\giza_workspace\Sunda_kejadian_1.txt .\giza_workspace\Inggri-sunda.paralel

# Reading alignment keys
def read_file_into_list(file):
    list = []
    with open(file, 'r', encoding='UTF-8') as fin:
        for line in fin.readlines():
            list.append(line.strip())
    return list

# Input parameters
source_file = sys.argv[1]
target_file = sys.argv[2]
output_file = sys.argv[3]
list_source = read_file_into_list(source_file)
list_target = read_file_into_list(target_file)
id = 0

with open(output_file, 'w', encoding='UTF-8') as paralel_file:   
    for data in list_source:
        paralel_file.write(data + ' ||| ' + list_target[id] + '\n')
        id = id + 1