#fungsi untuk mengkombinasi report cross-lingual hasil dari bahasa indonesia dan bahasa inggris
#setiap kata POS nya akan di combine contoh
# report 1: Poe NOUN_55 ***_155
# report 2: Poe ***_137 NOUN_41 ADP_32 
# hasil kombinasi : Poe NOUN_41 ADP_32 ***_292

import sys

def loadDataPOSFrequency(file_name_report):
    pos_data = {}
    lineCount = 0
    with open(file_name_report, 'r',  encoding='utf-8') as file:
        # Read each line in the file
        for line in file:
            lineCount = lineCount + 1
            # add all lexicon_dict
            if lineCount > 4:
                word = line.strip()
                dataWord = word.split()
                tempWord = dataWord[0]
                if tempWord not in pos_data:
                    pos_data[tempWord] = {}
                for i in range(1, len(dataWord)):
                        dataPOS = dataWord[i].split("_")
                        pos_data[tempWord][dataPOS[0]] = int(dataPOS[1])
    return pos_data

def combinePOS(dataPOS1, dataPOS2):
    for word in dataPOS1:
         if word in dataPOS2:
              tempPOS = dataPOS2[word]
              listPOS = list(tempPOS.keys())
              for pos in listPOS:
                   if pos in dataPOS1[word]:
                        dataPOS1[word][pos] = dataPOS1[word][pos] + dataPOS2[word][pos]
                   else :
                        dataPOS1[word][pos] = dataPOS2[word][pos]
    return dataPOS1

report_file_1 = sys.argv[1]
report_file_2 = sys.argv[2]
output_file = sys.argv[3]
pos_report1 = loadDataPOSFrequency(report_file_1)
pos_report2 = loadDataPOSFrequency(report_file_2)
combine_pos = combinePOS(pos_report1, pos_report2)
print(combine_pos["Kejadian"])

with open(output_file, 'w', encoding='UTF-8') as statistic_file:
    i = 0
    statistic_file.write( "Total Kata:  - \n")
    statistic_file.write( "Total Kata dengan POS: - \n")
    statistic_file.write( "Persentasi prediksi POS: \n\n")
    listWord = list(combine_pos.keys())
    for word in combine_pos:
        keysList = list(combine_pos[word].keys())
        posData = ""
        for pos in keysList:
            posData = posData + pos + "_" + str(combine_pos[word][pos]) + " "
        statistic_file.write(word + " " + posData + '\n')
        i = i + 1