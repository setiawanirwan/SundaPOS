import requests
from bs4 import BeautifulSoup

# URL website yang akan diambil datanya

def getDataWeb(base_url, page):
    # Mengambil konten dari website
    url = base_url + "/"+str(page)+"/"
    print(url)
    response = requests.get(url)
    # Periksa apakah request berhasil
    if response.status_code == 200:
        # Parsing HTML
        soup = BeautifulSoup(response.text, 'html.parser')
        # Mengambil elemen <div> berdasarkan ID (contoh ID: 'spesifik-id')
        div_element = soup.find('div', id='passage-text')  # Ganti 'spesifik-id' dengan ID elemen
        content = ""
        # Memastikan elemen <div> ditemukan
        if div_element:
            # Mengambil semua elemen <p> di dalam <div>
            p_elements = div_element.find_all('p')
            
            # Mengambil teks dari setiap elemen <p>
            for idx, p in enumerate(p_elements, 1):
                # print(f"Teks di <p> ke-{idx}: {p.get_text(strip=True)}")
                content = content + p.get_text(strip=False) + "\n"
        else:
            print("Elemen <div> dengan ID tidak ditemukan.")
        
        return content
    else:
        print(f"Gagal mengambil data. Status code: {response.status_code}")

def scrapData(url, max_page, chapter, filename):
    base_url = url
    max_page = max_page
    chapter = chapter
    file_name = filename
    listContent =[]
    # Loop data page
    for page in range(1, max_page + 1):
        data = getDataWeb(base_url, page)
        listContent.append(data)

    # Menyimpan ke file teks
    with open(file_name, "w", encoding="utf-8") as file:
        for index, content in enumerate(listContent):
            file.write(chapter+str(index+1)+"\n")
            file.write(content)
    print("Data berhasil disimpan ke '"+file_name+"'")


base_url = ["https://alkitab.mobi/tb/Neh",
            "https://alkitab.mobi/tb/Est", "https://alkitab.mobi/tb/Ayb", "https://alkitab.mobi/tb/Mzm", "https://alkitab.mobi/tb/Ams",
            "https://alkitab.mobi/tb/Pkh", "https://alkitab.mobi/tb/Kid", "https://alkitab.mobi/tb/Yes", "https://alkitab.mobi/tb/Yer",
            "https://alkitab.mobi/tb/Rat", "https://alkitab.mobi/tb/Yeh", "https://alkitab.mobi/tb/Dan", "https://alkitab.mobi/tb/Hos",
            "https://alkitab.mobi/tb/Yoe", "https://alkitab.mobi/tb/Amo", "https://alkitab.mobi/tb/Oba", "https://alkitab.mobi/tb/Yun",
            "https://alkitab.mobi/tb/Mik", "https://alkitab.mobi/tb/Nah", "https://alkitab.mobi/tb/Hab", "https://alkitab.mobi/tb/Zef",
            "https://alkitab.mobi/tb/Hag", "https://alkitab.mobi/tb/Zak", "https://alkitab.mobi/tb/Mal",
            "https://alkitab.mobi/tb/Mat", "https://alkitab.mobi/tb/Mrk", "https://alkitab.mobi/tb/Luk", "https://alkitab.mobi/tb/Yoh",
            "https://alkitab.mobi/tb/Kis", "https://alkitab.mobi/tb/Rom", "https://alkitab.mobi/tb/1Ko", "https://alkitab.mobi/tb/2Ko",
            "https://alkitab.mobi/tb/Gal", "https://alkitab.mobi/tb/Efe", "https://alkitab.mobi/tb/Flp", "https://alkitab.mobi/tb/Kol",
            "https://alkitab.mobi/tb/1Te", "https://alkitab.mobi/tb/2Te", "https://alkitab.mobi/tb/1Ti", "https://alkitab.mobi/tb/2Ti",
            "https://alkitab.mobi/tb/Tit", "https://alkitab.mobi/tb/Flm", "https://alkitab.mobi/tb/Ibr", "https://alkitab.mobi/tb/Yak",
            "https://alkitab.mobi/tb/1Pt", "https://alkitab.mobi/tb/2Pt", "https://alkitab.mobi/tb/1Yo", "https://alkitab.mobi/tb/2Yo",
            "https://alkitab.mobi/tb/3Yo", "https://alkitab.mobi/tb/Yud", "https://alkitab.mobi/tb/Why"]
max_page = [13,
            10, 42, 150, 31,
            12, 8, 66, 52,
            5, 48, 12, 14,
            3, 9, 1, 4,
            7, 3, 3, 3,
            2, 14, 4,
            28, 16, 24, 21,
            28, 16, 16, 13,
            6, 6, 4, 4,
            5, 3, 6, 4,
            3, 1, 13, 5,
            5, 3, 5, 1,
            1, 1, 22]
chapter = ["Nehemia ",
           "Ester ","Ayub ","Mazmur ", "Amsal ",
           "Pengkhotbah ","Kidung Agung ","Yesaya ", "Yeremia ",
           "Ratapan ","Yehezkiel ","Daniel ", "Hosea ",
           "Yoel ","Amos ","Obaja ", "Yunus ",
           "Mikha ","Nahum ","Habakuk ", "Zefanya ",
           "Hagai ","Zakharia ","Maleakhi ",
           "Matius ","Markus ","Lukas ", "Yohanes ",
           "Kisah Para Rasul ","Roma ","1 Korintus ", "2 Korintus ",
           "Galatia ","Efesus ","Filipi ", "Kolose ",
           "1 Tesalonika ","2 Tesalonika ","1 Timotius ", "2 Timotius ",
           "Titus ","Filemon ","Ibrani ", "Yakobus ",
           "1 Petrus ","2 Petrus ","1 Yohanes ", "2 Yohanes ",
           "3 Yohanes ","Yudas ","Wahyu "]
file_name = ["nehemia_indonesia.txt",
             "ester_indonesia.txt", "ayub_indonesia.txt", "mazmur_indonesia.txt", "amsal_indonesia.txt",
             "pengkhotbah_indonesia.txt", "kidung_agung_indonesia.txt", "yesaya_indonesia.txt", "yeremia_indonesia.txt",
             "ratapan_indonesia.txt", "yehezkiel_indonesia.txt", "daniel_indonesia.txt", "hosea_indonesia.txt",
             "yoel_indonesia.txt", "amos_indonesia.txt", "obaja_indonesia.txt", "yunus_indonesia.txt",
             "mikha_indonesia.txt", "nahum_indonesia.txt", "habakuk_indonesia.txt", "zefanya_indonesia.txt",
             "hagai_indonesia.txt", "zakharia_indonesia.txt", "maleakhi_indonesia.txt",
             "matius_indonesia.txt", "markus_indonesia.txt", "lukas_indonesia.txt", "yohanes_indonesia.txt",
             "kisah_para_rasul_indonesia.txt", "roma_indonesia.txt", "1_korintus_indonesia.txt", "2_korintus_indonesia.txt",
             "galatia_indonesia.txt", "efesus_indonesia.txt", "filipi_indonesia.txt", "kolose_indonesia.txt",
             "1_tesalonika_indonesia.txt", "2_tesalonika_indonesia.txt", "1_timotius_indonesia.txt", "2_timotius_indonesia.txt",
             "titus_indonesia.txt", "filemon_indonesia.txt", "ibrani_indonesia.txt", "yakobus_indonesia.txt",
             "1_petrus_indonesia.txt", "2_petrus_indonesia.txt", "1_yohanes_indonesia.txt", "2_yohanes_indonesia.txt",
             "3_yohanes_indonesia.txt", "yudas_indonesia.txt", "wahyu_indonesia.txt"]
for idx, url_data in enumerate(base_url): 
    scrapData(url_data, max_page[idx], chapter[idx], file_name[idx])