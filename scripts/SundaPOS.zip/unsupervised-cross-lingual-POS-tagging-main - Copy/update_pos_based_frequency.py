# program untuk memberikan tag POS pada kata berdsarkan data report POS cross-lingual
# POS yang diambil adalah POS yang bukan *** dan memiliki frequensi terbanyak
# input : file_text, file_report
# output : file_text dengan pos dengan format id <tab> kata_POS kata_POS dst

# print(hasil_tagging)
import sys

# Reading alignment keys
def read_file_into_list(file):
    list = []
    with open(file, 'r', encoding='UTF-8') as fin:
        for line in fin.readlines():
            list.append(line.strip())
    return list

def loadLexiconFromCrossLingual(lexicon, file_name_report):
    lineCount = 0
    with open(file_name_report, 'r',  encoding='utf-8') as file:
        # Read each line in the file
        for line in file:
            lineCount = lineCount + 1
            # add all lexicon_dict
            if lineCount > 4:
                word = line.strip()
                dataWord = word.split()
                tempWord = dataWord[0]
                pos = ''
                count = 0
                for i in range(len(dataWord)-1):
                    dataPOS = dataWord[i+1].split("_")
                    if dataPOS[0] != '***':
                        tempCount = int(dataPOS[1])
                        if tempCount > count :
                            pos = dataPOS[0]
                            count = tempCount
                if pos != '':
                    lexicon[tempWord.lower()] = pos 
    return lexicon

def pos_tagged(lexicon, word):
    # Jika kata ada di kamus
    if word in lexicon:
        return lexicon[word]
    else:
        return "***"

source_file = sys.argv[1]
crossLingualFrequency_file = sys.argv[2]
output_file = sys.argv[3]
list_sentences = read_file_into_list(source_file)
lexicon = {}
tagged_sentences = []
loadLexiconFromCrossLingual(lexicon, crossLingualFrequency_file)

for sentence in list_sentences:
    words = sentence.split()
    tagged_sentence = ''
    for idx, word in enumerate(words):
        tagged_sentence = tagged_sentence + word + '_' + pos_tagged(lexicon, word.lower()) + ' '
        
    tagged_sentences.append(tagged_sentence)

id = 1
with open(output_file, 'w', encoding='UTF-8') as tagged_file:
    for data in tagged_sentences:
        tagged_file.write(str(id) + '\t' + data + '\n')
        id = id + 1