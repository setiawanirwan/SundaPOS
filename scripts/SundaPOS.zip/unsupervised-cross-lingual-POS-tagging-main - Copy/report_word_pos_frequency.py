import sys

# HOW TO USE
# modul untuk merekap kemunculan POS tiap kata
# python .\report_word_pos_frequency.py pos_file_path output_file_path 
# python .\report_word_pos_frequency.py .\giza_workspace\pos_output.txt .\giza_workspace\report_frequency.txt

# Reading alignment keys
def read_file_into_list(file):
    list = []
    with open(file, 'r', encoding='UTF-8') as fin:
        for line in fin.readlines():
            list.append(line.strip())
    return list

def findWord (dataWords, word):
    i = 0
    for data in dataWords:
        if data == word:
            return i
        i = i + 1
    return -1


# Input parameters
source_file = sys.argv[1]
output_file = sys.argv[2]
list_sentences = read_file_into_list(source_file)
id = 1
dataWords = []
dataPOS = []
wordCount = 0
for sentences in list_sentences:   
    elements = sentences.split("\t")
    words = elements[1].split(" ")
    for word in words :
       wordCount = wordCount + 1
       elements = word.split("_")
       indexWord = findWord(dataWords, elements[0])
       if indexWord == -1 :
           temp = {}
           temp[elements[1]] = 1
           dataPOS.append(temp)
           dataWords.append(elements[0])
       else:
           temp = dataPOS[indexWord]
           if elements[1] in temp:
               temp[elements[1]] += 1
           else:
               temp[elements[1]] = 1
# print(dataWords)
# print(dataPOS)
i=0
countPOS = 0
for data in dataWords:
    keysList = list(dataPOS[i].keys())
    for pos in keysList:
        if pos != "***":
            countPOS = countPOS + dataPOS[i][pos]
    i = i + 1

with open(output_file, 'w', encoding='UTF-8') as statistic_file:
    i = 0
    statistic_file.write( "Total Kata: " + str(wordCount) + '\n')
    statistic_file.write( "Total Kata dengan POS: " + str(countPOS) + '\n')
    statistic_file.write( "Persentasi prediksi POS: " + str((countPOS/wordCount)*100) + '\n\n')
    for data in dataWords:
        keysList = list(dataPOS[i].keys())
        posData = ""
        for pos in keysList:
            posData = posData + pos + "_" + str(dataPOS[i][pos]) + " "
        statistic_file.write(data + " " + posData + '\n')
        i = i + 1