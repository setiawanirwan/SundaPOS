# import spacy

# Load model spaCy untuk Bahasa Indonesia
# if model not found execute command python -m spacy download xx_ent_wiki_sm 
# nlp = spacy.load("xx_ent_wiki_sm")

# # Contoh kalimat
# kalimat = "Saya sedang belajar pemrograman Python."
# doc = nlp(kalimat)

# # POS Tagging
# for token in doc:
#     print(f"{token.text}: {token.pos_}")

# import nltk
# from nltk.tokenize import word_tokenize
# from nltk.tag import UnigramTagger
# from nltk.corpus import treebank

# # Contoh kalimat
# kalimat = "Saya sedang belajar pemrograman Python."

# # Tokenisasi
# kata = word_tokenize(kalimat)

# # Model tagging sederhana (menggunakan bahasa Inggris, ganti dengan dataset Indonesia)
# tagger = UnigramTagger(treebank.tagged_sents())
# hasil_tagging = tagger.tag(kata)

# print(hasil_tagging)
import sys
import stanza

# Unduh model untuk Bahasa Indonesia
stanza.download('id')

# Load pipeline Stanza
nlp = stanza.Pipeline('id')

# Reading alignment keys
def read_file_into_list(file):
    list = []
    with open(file, 'r', encoding='UTF-8') as fin:
        for line in fin.readlines():
            list.append(line.strip())
    return list

# Contoh kalimat
# kalimat = "Saya sedang belajar pemrograman Python."
# doc = nlp(kalimat)

# # POS Tagging
# for sentence in doc.sentences:
#     for word in sentence.words:
#         print(f"{word.text}: {word.upos}")

source_file = sys.argv[1]
output_file = sys.argv[2]
list_sentences = read_file_into_list(source_file)
tagged_sentences = []
for sentence in list_sentences:
    doc = nlp(sentence)
    tagged_sentence = ''
    for kalimat in doc.sentences:
        for word in kalimat.words:
            print(f"{word.text}: {word.upos}")
            tagged_sentence = tagged_sentence + word.text + '_' + word.upos + ' '
    tagged_sentences.append(tagged_sentence)
id = 1
with open(output_file, 'w', encoding='UTF-8') as tagged_file:
    for data in tagged_sentences:
        tagged_file.write(str(id) + '\t' + data + '\n')
        id = id + 1