import sys

def loadPOSData(source_file):
    lexicon = {}
    lineCount = 0
    with open(source_file, 'r',  encoding='utf-8') as file:
        # Read each line in the file
        for line in file:
            lineCount = lineCount + 1
            # add all lexicon_dict
            if lineCount > 4:
                word = line.strip()
                dataWord = word.split()
                tempWord = dataWord[0]
                dataPOS = dataWord[1].split("_")
                lexicon[tempWord] = dataPOS[0] 
    return lexicon

def getJumlahUniqueKataTiapPOS(source_file):
    data = {}
    lineCount = 0
    with open(source_file, 'r',  encoding='utf-8') as file:
        # Read each line in the file
        total = 0
        for line in file:
            lineCount = lineCount + 1
            # add all lexicon_dict
            if lineCount > 4:
                word = line.strip()
                dataWord = word.split()
                dataPOS = dataWord[1].split("_")
                if dataPOS[0] in data:
                   data[dataPOS[0]] = data[dataPOS[0]] + 1
                else:
                   data[dataPOS[0]] = 1
                total = total + 1
        print("total : " + str(total))
    return data

def getJumlahKataTiapPOS(source_file):
    data = {}
    lineCount = 0
    with open(source_file, 'r',  encoding='utf-8') as file:
        # Read each line in the file
        total = 0
        for line in file:
            lineCount = lineCount + 1
            # add all lexicon_dict
            if lineCount > 4:
                word = line.strip()
                dataWord = word.split()
                dataPOS = dataWord[1].split("_")
                if dataPOS[0] in data:
                   data[dataPOS[0]] = data[dataPOS[0]] + int(dataPOS[1])
                else:
                   data[dataPOS[0]] = int(dataPOS[1])
                total = total + int(dataPOS[1])
        print("total : " + str(total))
    return data

source_file = sys.argv[1]
listPOS = loadPOSData(source_file)
dataPOS = set(listPOS.values())
dataWord = set(listPOS.keys())
print("jumlah kata:" + str(len(dataWord)) )
print("jumlah jenis pos:" + str(len(dataPOS)))
jumlahKataTiapPOS = getJumlahKataTiapPOS(source_file)
print("jumlah kata tiap pos :")
print(jumlahKataTiapPOS)
