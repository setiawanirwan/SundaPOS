import requests
from bs4 import BeautifulSoup

def getDataWeb(base_url, page):
    # Mengambil konten dari website
    url = base_url + "/"+str(page)+"/"
    print(url)
    response = requests.get(url)
    # Periksa apakah request berhasil
    if response.status_code == 200:
        # Parsing HTML
        soup = BeautifulSoup(response.text, 'html.parser')
        for element in soup.find_all(string=lambda text: "2010-2024" in text):
            element.parent.decompose()  # Menghapus elemen induk yang mengandung teks

        for span in soup.find_all('span'):
            # Menghapus element span
            span.unwrap()
        modified_html = soup.prettify()
        soup = BeautifulSoup(modified_html, 'html.parser')
        # print(modified_html)
        # Misalnya, mengambil semua teks dari elemen paragraf
        paragraphs = soup.find_all('p')
        content = "\n".join([p.get_text().replace("\n", "").replace("     ","").replace("  ","") for p in paragraphs])
        return content + "\n"
    else:
        print(f"Gagal mengambil data. Status code: {response.status_code}")

# URL website yang akan diambil datanya
def scrapData(url, max_page, chapter, filename):
    base_url = url
    max_page = max_page
    chapter = chapter
    file_name = filename
    listContent =[]

    # Loop data page
    for page in range(1, max_page + 1):
        data = getDataWeb(base_url, page)
        listContent.append(data)

    # Menyimpan ke file teks
    with open(file_name, "w", encoding="utf-8") as file:
        for index, content in enumerate(listContent):
            file.write(chapter+str(index+1)+"\n")
            file.write(content)
    print("Data berhasil disimpan ke '"+file_name+"'")

# base_url = ["https://alkitab.mobi/sunda/", "https://alkitab.mobi/sunda/", "https://alkitab.mobi/sunda/", "https://alkitab.mobi/sunda/"]
# max_page = [, , , ]
# chapter = [" "," "," ", " "]
# file_name = ["_sunda.txt", "_sunda.txt", "_sunda.txt", "_sunda.txt"]
base_url = ["https://alkitab.mobi/sunda/Gal", "https://alkitab.mobi/sunda/Efe", "https://alkitab.mobi/sunda/Flp", "https://alkitab.mobi/sunda/Kol",
            "https://alkitab.mobi/sunda/1Te", "https://alkitab.mobi/sunda/2Te", "https://alkitab.mobi/sunda/1Ti", "https://alkitab.mobi/sunda/2Ti",
            "https://alkitab.mobi/sunda/Tit", "https://alkitab.mobi/sunda/Flm", "https://alkitab.mobi/sunda/Ibr", "https://alkitab.mobi/sunda/Yak",
            "https://alkitab.mobi/sunda/1Pt", "https://alkitab.mobi/sunda/2Pt", "https://alkitab.mobi/sunda/1Yo", "https://alkitab.mobi/sunda/2Yo",
            "https://alkitab.mobi/sunda/3Yo", "https://alkitab.mobi/sunda/Yud", "https://alkitab.mobi/sunda/Why"]
max_page = [6, 6, 4, 4,
            5, 3, 6, 4,
            3, 1, 13, 5,
            5, 3, 5, 1,
            1, 1, 22]
chapter = ["Galatia ","Efesus ","Filipi ", "Kolose ",
           "1 Tesalonika ","2 Tesalonika ","1 Timotius ", "2 Timotius ",
           "Titus ","Filemon ","Ibrani ", "Yakobus ",
           "1 Petrus ","2 Petrus ","1 Yohanes ", "2 Yohanes ",
           "3 Yohanes ","Yudas ","Wahyu "]
file_name = ["galatia_sunda.txt", "efesus_sunda.txt", "filipi_sunda.txt", "kolose_sunda.txt",
             "1_tesalonika_sunda.txt", "2_tesalonika_sunda.txt", "1_timotius_sunda.txt", "2_timotius_sunda.txt",
             "titus_sunda.txt", "filemon_sunda.txt", "ibrani_sunda.txt", "yakobus_sunda.txt",
             "1_petrus_sunda.txt", "2_petrus_sunda.txt", "1_yohanes_sunda.txt", "2_yohanes_sunda.txt",
             "3_yohanes_sunda.txt", "yudas_sunda.txt", "wahyu_sunda.txt"]
for idx, url_data in enumerate(base_url): 
    scrapData(url_data, max_page[idx], chapter[idx], file_name[idx])