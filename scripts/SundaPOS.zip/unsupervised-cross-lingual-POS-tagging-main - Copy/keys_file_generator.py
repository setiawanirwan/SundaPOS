import sys
# HOW TO USE
# python .\keys_file_generator.py source_file_path output_file_path 
# python .\keys_file_generator.py .\giza_workspace\Inggris_kejadian_1.txt .\giza_workspace\Tagged_inggris_kejadian_1.keys


# Reading alignment keys
def read_file_into_list(file):
    list = []
    with open(file, 'r', encoding='UTF-8') as fin:
        for line in fin.readlines():
            list.append(line.strip())
    return list

# Input parameters
source_file = sys.argv[1]
output_file = sys.argv[2]
list_sentences = read_file_into_list(source_file)

id = 1
with open(output_file, 'w', encoding='UTF-8') as tagged_file:
    for data in list_sentences:
        tagged_file.write(str(id) + '\n')
        id = id + 1