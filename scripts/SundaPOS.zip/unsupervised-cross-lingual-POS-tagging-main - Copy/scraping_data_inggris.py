import requests
from bs4 import BeautifulSoup

# URL website yang akan diambil datanya
def getDataWeb(base_url, page):
    # Mengambil konten dari website
    url = base_url + "/"+str(page)+"/"
    print(url)
    response = requests.get(url)
    # Periksa apakah request berhasil
    if response.status_code == 200:
        # Parsing HTML
        soup = BeautifulSoup(response.text, 'html.parser')
        for span in soup.find_all('span'):
            # Menghapus element span
            span.unwrap()
        for span in soup.find_all('a'):
            # Menghapus element span
            span.insert_after("&nbsp;")
        
        modified_html = soup.prettify()

        soup = BeautifulSoup(modified_html, 'html.parser')
        div_elements = soup.find_all('div')
        content = ""
        # Memastikan elemen <div> ditemukan
        if len(div_elements)>2:
            # Mengambil semua elemen <p> di dalam <div>
            first_p = div_elements[2].find('p')
        
            if first_p:
                content = content + first_p.get_text(strip=True).replace("&nbsp;\n    ", " ").replace("    "," ").replace("  "," ") + "\n"
                for elem in first_p.find_all_next():  # Mengiterasi elemen setelah <p> pertama
                    if elem.name == 'p':  # Tambahkan elemen <p> ke dalam daftar
                        # elements.append(elem.get_text(strip=True))
                        content = content + elem.get_text(strip=True).replace("&nbsp;\n    ", " ").replace("    "," ").replace("  "," ") + "\n"
                    elif elem.name == 'hr':  # Berhenti jika menemukan <hr>
                        break
                    
            # Mengambil teks dari setiap elemen <p>
            # for idx, p in enumerate(p_elements, 1):
            #     # print(f"Teks di <p> ke-{idx}: {p.get_text(strip=True)}")
            #     content = content + p.get_text(strip=False) + "\n"
        else:
            print("Elemen <div> dengan ID tidak ditemukan.")
        
        return content + "\n"
    else:
        print(f"Gagal mengambil data. Status code: {response.status_code}")
def scrapData(url, maxpage, chapter, filename):
    base_url = url
    max_page = maxpage
    chapter = chapter
    file_name = filename
    listContent =[]
    # Loop data page
    for page in range(1, max_page + 1):
        data = getDataWeb(base_url, page)
        listContent.append(data)

    # Menyimpan ke file teks
    with open(file_name, "w", encoding="utf-8") as file:
        for index, content in enumerate(listContent):
            file.write(chapter+str(index+1)+"\n")
            file.write(content)
    print("Data berhasil disimpan ke '"+file_name+"'")


base_url = ["https://alkitab.mobi/net/Neh",
            "https://alkitab.mobi/net/Est", "https://alkitab.mobi/net/Ayb", "https://alkitab.mobi/net/Mzm", "https://alkitab.mobi/net/Ams",
            "https://alkitab.mobi/net/Pkh", "https://alkitab.mobi/net/Kid", "https://alkitab.mobi/net/Yes", "https://alkitab.mobi/net/Yer",
            "https://alkitab.mobi/net/Rat", "https://alkitab.mobi/net/Yeh", "https://alkitab.mobi/net/Dan", "https://alkitab.mobi/net/Hos",
            "https://alkitab.mobi/net/Yoe", "https://alkitab.mobi/net/Amo", "https://alkitab.mobi/net/Oba", "https://alkitab.mobi/net/Yun",
            "https://alkitab.mobi/net/Mik", "https://alkitab.mobi/net/Nah", "https://alkitab.mobi/net/Hab", "https://alkitab.mobi/net/Zef",
            "https://alkitab.mobi/net/Hag", "https://alkitab.mobi/net/Zak", "https://alkitab.mobi/net/Mal",
            "https://alkitab.mobi/net/Mat", "https://alkitab.mobi/net/Mrk", "https://alkitab.mobi/net/Luk", "https://alkitab.mobi/net/Yoh",
            "https://alkitab.mobi/net/Kis", "https://alkitab.mobi/net/Rom", "https://alkitab.mobi/net/1Ko", "https://alkitab.mobi/net/2Ko",
            "https://alkitab.mobi/net/Gal", "https://alkitab.mobi/net/Efe", "https://alkitab.mobi/net/Flp", "https://alkitab.mobi/net/Kol",
            "https://alkitab.mobi/net/1Te", "https://alkitab.mobi/net/2Te", "https://alkitab.mobi/net/1Ti", "https://alkitab.mobi/net/2Ti",
            "https://alkitab.mobi/net/Tit", "https://alkitab.mobi/net/Flm", "https://alkitab.mobi/net/Ibr", "https://alkitab.mobi/net/Yak",
            "https://alkitab.mobi/net/1Pt", "https://alkitab.mobi/net/2Pt", "https://alkitab.mobi/net/1Yo", "https://alkitab.mobi/net/2Yo",
            "https://alkitab.mobi/net/3Yo", "https://alkitab.mobi/net/Yud", "https://alkitab.mobi/net/Why"]
max_page = [13,
            10, 42, 150, 31,
            12, 8, 66, 52,
            5, 48, 12, 14,
            3, 9, 1, 4,
            7, 3, 3, 3,
            2, 14, 4,
            28, 16, 24, 21,
            28, 16, 16, 13,
            6, 6, 4, 4,
            5, 3, 6, 4,
            3, 1, 13, 5,
            5, 3, 5, 1,
            1, 1, 22]
chapter = ["Nehemia ",
           "Ester ","Ayub ","Mazmur ", "Amsal ",
           "Pengkhotbah ","Kidung Agung ","Yesaya ", "Yeremia ",
           "Ratapan ","Yehezkiel ","Daniel ", "Hosea ",
           "Yoel ","Amos ","Obaja ", "Yunus ",
           "Mikha ","Nahum ","Habakuk ", "Zefanya ",
           "Hagai ","Zakharia ","Maleakhi ",
           "Matius ","Markus ","Lukas ", "Yohanes ",
           "Kisah Para Rasul ","Roma ","1 Korintus ", "2 Korintus ",
           "Galatia ","Efesus ","Filipi ", "Kolose ",
           "1 Tesalonika ","2 Tesalonika ","1 Timotius ", "2 Timotius ",
           "Titus ","Filemon ","Ibrani ", "Yakobus ",
           "1 Petrus ","2 Petrus ","1 Yohanes ", "2 Yohanes ",
           "3 Yohanes ","Yudas ","Wahyu "]
file_name = ["nehemia_inggris.txt",
             "ester_inggris.txt", "ayub_inggris.txt", "mazmur_inggris.txt", "amsal_inggris.txt",
             "pengkhotbah_inggris.txt", "kidung_agung_inggris.txt", "yesaya_inggris.txt", "yeremia_inggris.txt",
             "ratapan_inggris.txt", "yehezkiel_inggris.txt", "daniel_inggris.txt", "hosea_inggris.txt",
             "yoel_inggris.txt", "amos_inggris.txt", "obaja_inggris.txt", "yunus_inggris.txt",
             "mikha_inggris.txt", "nahum_inggris.txt", "habakuk_inggris.txt", "zefanya_inggris.txt",
             "hagai_inggris.txt", "zakharia_inggris.txt", "maleakhi_inggris.txt",
             "matius_inggris.txt", "markus_inggris.txt", "lukas_inggris.txt", "yohanes_inggris.txt",
             "kisah_para_rasul_inggris.txt", "roma_inggris.txt", "1_korintus_inggris.txt", "2_korintus_inggris.txt",
             "galatia_inggris.txt", "efesus_inggris.txt", "filipi_inggris.txt", "kolose_inggris.txt",
             "1_tesalonika_inggris.txt", "2_tesalonika_inggris.txt", "1_timotius_inggris.txt", "2_timotius_inggris.txt",
             "titus_inggris.txt", "filemon_inggris.txt", "ibrani_inggris.txt", "yakobus_inggris.txt",
             "1_petrus_inggris.txt", "2_petrus_inggris.txt", "1_yohanes_inggris.txt", "2_yohanes_inggris.txt",
             "3_yohanes_inggris.txt", "yudas_inggris.txt", "wahyu_inggris.txt"]
for idx, url_data in enumerate(base_url): 
    scrapData(url_data, max_page[idx], chapter[idx], file_name[idx])
    