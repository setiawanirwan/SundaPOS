import sys

def read_file_into_list(file):
    list = []
    with open(file, 'r', encoding='UTF-16') as fin:
        for line in fin.readlines():
            list.append(line.strip())
    return list

input_file = sys.argv[1]
list_sentences = read_file_into_list(input_file)
for sentence in list_sentences:
    print(sentence)